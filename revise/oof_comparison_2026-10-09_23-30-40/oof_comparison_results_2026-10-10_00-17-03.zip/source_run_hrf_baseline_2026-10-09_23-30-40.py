"""New subject-disjoint experiment; never a recovery of manuscript 0.835."""
import csv
import hashlib
import json
import math
import random
import sys
from pathlib import Path
import cv2
import numpy as np
import torch
from torch import nn
import torch.nn.functional as F
from PIL import Image
from official_model import LNet_RA

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from diffusion_refiner.models import MaskAutoencoder, ImageEncoder, DiffusionUNet

OUT = Path(__file__).resolve().parent / 'hrf_results'
OUT.mkdir(exist_ok=True)
torch.set_num_threads(4)
torch.manual_seed(42)
np.random.seed(42)
random.seed(42)
torch.backends.cudnn.deterministic = True
torch.backends.cudnn.benchmark = False
torch.backends.cuda.matmul.allow_tf32 = False
torch.backends.cudnn.allow_tf32 = False
DEVICE = torch.device('cuda')

def dice(p, g):
    return (2*(p*g).sum()+1e-6)/(p.sum()+g.sum()+1e-6)

def score(p, g, fov):
    p=p[fov]; g=g[fov]
    p = p >= .5
    g = g >= .5
    tp = (p & g).sum().item(); fp = (p & ~g).sum().item()
    fn = (~p & g).sum().item(); tn = (~p & ~g).sum().item()
    return dict(dice=2*tp/max(2*tp+fp+fn,1), iou=tp/max(tp+fp+fn,1),
                sensitivity=tp/max(tp+fn,1), specificity=tn/max(tn+fp,1),
                accuracy=(tp+tn)/(tp+fp+fn+tn), tp=tp, fp=fp, fn=fn, tn=tn)

import base64,zlib,io
base=Path('F:/PHD/AI in Med/retina_diffusion_clean/data/raw/HRF/ds')
rng=np.random.default_rng(42)
splits={}
for category in ['h','dr','g']:
    names=[p.stem for p in sorted((base/'img').glob(f'*_{category}.jpg'))]
    assert len(names)==15
    names=rng.permutation(names).tolist()
    for k,selected in [('train',names[:9]),('validation',names[9:11]),('test',names[11:])]:
        for name in selected:splits[name]=k

def bitmap(obj,size):
    im=Image.open(io.BytesIO(zlib.decompress(base64.b64decode(obj['bitmap']['data']))))
    patch=np.asarray(im)>0
    if patch.ndim!=2:raise ValueError('Expected indexed binary bitmap')
    canvas=np.zeros((size['height'],size['width']),dtype=np.uint8)
    x,y=obj['bitmap']['origin'];canvas[y:y+patch.shape[0],x:x+patch.shape[1]]=patch
    return cv2.resize(canvas,(512,512),interpolation=cv2.INTER_NEAREST).astype(bool)

data={}
for path in sorted((base/'img').glob('*.jpg')):
    name=path.stem; ann=base/'ann'/f'{path.name}.json';doc=json.load(open(ann))
    objects={o['classTitle']:o for o in doc['objects']}
    assert 'vessels' in objects and 'field of view' in objects
    mask=bitmap(objects['vessels'],doc['size']);fov=bitmap(objects['field of view'],doc['size'])
    rgb=np.asarray(Image.open(path).convert('RGB'))
    assert rgb.shape[:2]==(doc['size']['height'],doc['size']['width'])
    assert .01<mask.mean()<.3 and fov.mean()>.5
    green=cv2.createCLAHE(clipLimit=5.,tileGridSize=(32,32)).apply(rgb[:,:,1])
    green=np.uint8(np.clip((green/255.)**(1/1.2)*255,0,255))
    green=cv2.resize(green,(512,512),interpolation=cv2.INTER_LINEAR)
    color=cv2.resize(rgb,(512,512),interpolation=cv2.INTER_LINEAR)
    data[name]=dict(split=splits[name],x=torch.tensor(green/255.,dtype=torch.float32)[None],rgb=torch.tensor(color/255.,dtype=torch.float32).permute(2,0,1),g=torch.tensor(mask,dtype=torch.float32)[None],fov=torch.tensor(fov)[None],image_path=str(path),gt_path=str(ann),fov_path=str(ann))
manifest={k:[n for n,d in data.items() if d['split']==k] for k in ['train','validation','test']}
assert [len(manifest[k]) for k in manifest]==[27,6,12]
config=dict(split=manifest,seed=42,threshold=.5,region='JSON field of view bitmap resized nearest',size=512,precision='FP32',baseline='official RVS LNet_RA in_channels=1',baseline_max_epochs=1000,baseline_patience=20,baseline_lr=.001,weight_decay=.001,annotation_source=str(base),annotation_provenance='local HRF Supervisely JSON vessels and field of view classes; original conversion provenance not documented',split_rule='stratified by h/dr/g; 9 train, 2 validation, 4 test each',claim='new HRF baseline; not a verified same-protocol comparator for original diffusion 0.762/0.793')
(OUT/'protocol.json').write_text(json.dumps(config,indent=2))
(OUT/'file_provenance.json').write_text(json.dumps({n:{k:d[k] for k in ['image_path','gt_path','fov_path']} for n,d in data.items()},indent=2))

def batches(split, augment=False):
    names = manifest[split].copy()
    if augment: random.shuffle(names)
    for start in range(0,len(names),4):
        samples=[]
        for name in names[start:start+4]:
            d={k:v.clone() if isinstance(v,torch.Tensor) else v for k,v in data[name].items()}
            if augment:
                angle=random.choice([0,15,30,45,90,100,120])
                from torchvision.transforms.functional import rotate
                from torchvision.transforms import InterpolationMode
                for k in ('x','rgb','g','fov'):
                    d[k]=rotate(d[k].float(),angle,interpolation=InterpolationMode.NEAREST if k in ('g','fov') else InterpolationMode.BILINEAR)
                for dim in (-1,-2):
                    if random.random()<.5:
                        for k in ('x','rgb','g','fov'): d[k]=d[k].flip(dim)
            samples.append(d)
        yield {k:torch.stack([d[k] for d in samples]).to(DEVICE) for k in ('x','rgb','g','fov')}, names[start:start+4]

model=LNet_RA(in_channels=1).to(DEVICE)
stage_initial_rng=torch.get_rng_state()
print('Baseline parameters',sum(p.numel() for p in model.parameters()),flush=True)
opt=torch.optim.AdamW(model.parameters(),lr=.001,weight_decay=.001)
best=-1.; stale=0
log=[]
for epoch in range(0 if '--resume-baseline' in sys.argv else 1000):
    model.train(); losses=[]
    for b,_ in batches('train',True):
        opt.zero_grad(); p=model(b['x']); loss=1-dice(p,b['g']); loss.backward(); opt.step(); losses.append(loss.item())
    model.eval()
    with torch.no_grad():
        val=np.mean([score(model(b['x'])[i],b['g'][i],b['fov'][i]>.5)['dice'] for b,_ in batches('validation') for i in range(len(b['g']))])
    log.append(dict(epoch=epoch+1,loss=float(np.mean(losses)),validation_dice=float(val)))
    (OUT/'baseline_training.json').write_text(json.dumps(log))
    if val>best:
        best=val; stale=0
        torch.save(dict(state=model.state_dict(),epoch=epoch+1,validation_dice=best,protocol=config),OUT/'baseline.pt')
    else: stale+=1
    print(f'baseline epoch {epoch+1} val={val:.4f} best={best:.4f} patience={stale}',flush=True)
    if stale>=20: break
# This checkpoint was created by this script; older local saves include a NumPy scalar.
saved=torch.load(OUT/'baseline.pt',weights_only=False)
saved['validation_dice']=float(saved['validation_dice'])
torch.save(saved,OUT/'baseline.pt')
model.load_state_dict(saved['state']); model.eval()

rows=[]
with torch.no_grad():
    for name in manifest['test']:
        d=data[name]; pred=model(d['x'][None].to(DEVICE)).cpu()[0]
        np.save(OUT/f'{name}_baseline.npy',pred.numpy())
        rows.append(dict(image=name,pathology=name.split('_')[1],**score(pred,d['g'],d['fov'])))
with (OUT/'per_image.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
summary={k:float(np.mean([r[k] for r in rows])) for k in ['dice','iou','accuracy','sensitivity','specificity']}
summary.update(n_images=12,training_seed=42,baseline_epoch=saved['epoch'],same_protocol_with_original_diffusion=False)
(OUT/'summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2),flush=True)
